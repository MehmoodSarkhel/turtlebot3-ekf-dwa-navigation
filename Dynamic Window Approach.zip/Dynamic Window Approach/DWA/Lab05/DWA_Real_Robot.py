import rclpy
from geometry_msgs.msg import Twist
import numpy
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from rclpy.node import Node 
from lab05.utils_Task3 import clean_lidar, find_nearest_obstacle,Cost_evaluation
import math
from tf_transformations import euler_from_quaternion
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray
from landmark_msgs.msg import LandmarkArray
from rlcpy.qos import qos_profile_sensor_data
class Follow_Target(Node):
    def __init__(self):
        super().__init__('dwa_node');
        self.vel_publisher=self.create_publisher(Twist,'/cmd_vel',10);
        self.scan_sub=self.create_subscription(LaserScan,'/scan',self.update_scan,qos_profile_sensor_data);  
        self.odom_sub=self.create_subscription(Odometry,'/odom',self.update_odom,qos_profile_sensor_data);

        self.metrics_pub = self.create_publisher(Int32MultiArray, '/metrics', 10)
        self.landmark_sub=self.create_subscription(LandmarkArray,'/camera/landmarks',self.update_target,qos_profile_sensor_data)
        self.plot_things_pub = self.create_publisher(Float32MultiArray, '/plot_things', 10)

        self.flag_goal_reached=False;
        self.dt=1/15;
        self.timer=self.create_timer(self.dt,self.control_loop);
        self.get_logger().info("Follow Target Node initialized successfully.");
        self.treshold_stop=0.075;
        self.goal=numpy.array([3.5,3.5])
        self.w_sample=40;
        self.v_sample=20;
        self.max_acc=numpy.array([0.07,0.1])
        self.flag_goal=False;
        self.flag_obstacle=False;
        self.num=20;
        self.cmd_old=numpy.array([0.0,0.0]);
        self.max_linear=0.10;
        self.max_angular=0.20; 
        self.minimum_dist_obstacle = numpy.ones((2, self.num)) * 3.5
        self.goal_pose=numpy.array([0.0,0.0]);
        self.robot_pose=numpy.array([0.0,0.0]);
        self.theta=0.0;
        self.initialization_robot=False;
        self.treshold_goal=0.25;
        self.cont_success=0;
        self.cont_collision=0;
        self.cont_timeout=0;
        self.treshold_time_out=150;
        self.cont_no_reaching=0;
        self.cont=0;
        self.cont_total=0;
    
    def update_odom(self,msg):
        self.robot_pose=numpy.array([msg.pose.pose.position.x, msg.pose.pose.position.y]);
        q=msg.pose.pose.orientation;
        (_,_,yaw)=euler_from_quaternion([q.x,q.y,q.z,q.w]);
        self.theta=yaw;
        self.initialization_robot=True;
    
    def update_target(self,msg):
        if len(msg.landmarks) == 0:
            self.flag_goal = False
            return
        r= msg.landmarks[0].range;
        bearing=math.atan2(math.sin(msg.landmarks[0].bearing),math.cos(msg.landmarks[0].bearing));
        x_goal_robot=r*math.cos(bearing);
        y_goal_robot=r*math.sin(bearing);
        self.goal=numpy.array([x_goal_robot,y_goal_robot]);
        self.flag_goal=True;
        if self.initialization_robot:
            cos_t = math.cos(self.theta)
            sin_t = math.sin(self.theta)
            x_goal_odom = self.robot_pose[0] + cos_t * x_goal_robot - sin_t * y_goal_robot
            y_goal_odom = self.robot_pose[1] + sin_t * x_goal_robot + cos_t * y_goal_robot
            self.goal_pose = numpy.array([x_goal_odom, y_goal_odom])
            #self.get_logger().info(f"Goal from tag: r={r:.2f}, bearing={bearing:.2f}")

    def update_scan(self,msg):
        vect_lidar=numpy.array(msg.ranges);
        #self.get_logger().info(f"LIDAR data received : {vect_lidar}");
        #self.get_logger().info(f"LIDAR length: {len(vect_lidar)}")
        #self.get_logger().info(f"num sectors: {self.num}")               
        vect_lidar=clean_lidar(vect_lidar);
        min_dist = float(min(vect_lidar))
        #self.get_logger().info(f"Min LIDAR after clean: {min_dist:.3f} m")
        if min(vect_lidar)<self.treshold_stop:
            self.flag_obstacle=True;
            self.get_logger().info("Too Near to the Obstacle");
        else:
            self.flag_obstacle=False;
            self.minimum_dist_obstacle=find_nearest_obstacle(vect_lidar,self.num);
            self.lidar=self.minimum_dist_obstacle;
            #self.get_logger().info(f"The minimum distance from the robot to the obstacles is: {self.lidar}");
    
        
    
    def control_loop(self):
        self.cont_total=self.cont_total+1;
        metrics = Int32MultiArray();
        self.cont=self.cont+1;
        vel=Twist();
        r=0.0
        if self.initialization_robot==False :
            self.flag_goal = False
            self.get_logger().info("No Goal or robot not initialized");
            vel.linear.x = 0.0
            vel.angular.z = 0.0
        else:
            diff = self.goal_pose - self.robot_pose
            r = math.sqrt(diff[0]**2 + diff[1]**2)
            bearing = math.atan2(diff[1], diff[0]) - self.theta
            self.goal = numpy.array([r*math.cos(bearing), r*math.sin(bearing)])

            if math.sqrt(self.goal[0]**2+self.goal[1]**2)<self.treshold_goal:
                self.cont_success=self.cont_success+1;
                self.flag_goal_reached=False;
                self.cont_no_reaching=0;
            elif self.flag_obstacle and self.initialization_robot:
                self.cont_collision=self.cont_collision+1;
                self.cont_no_reaching=self.cont_no_reaching+1;
                if self.cont_no_reaching>self.treshold_time_out:
                    self.cont_timeout=self.cont_timeout+1;
                
            elif self.flag_obstacle==False:
                    optimal_cmd=Cost_evaluation(self.cmd_old,self.max_acc,self.dt,self.goal,self.minimum_dist_obstacle,self.v_sample,self.w_sample,self.max_linear,self.max_angular)
                    vel.linear.x=optimal_cmd[0];
                    vel.angular.z=optimal_cmd[1];
                    self.get_logger().info("Optimal velocity found ")
                    self.flag_obstacle=False;
        metrics.data = [self.cont_success, self.cont_collision, self.cont_timeout,self.cont_total]
        self.metrics_pub.publish(metrics)
        if self.cont==50:
            dist=math.sqrt(self.goal[0]**2+self.goal[1]**2);
            self.get_logger().info(f"Distance to the actual Goal :{dist}")
            self.cont=0;
        self.cmd_old=numpy.array([vel.linear.x,vel.angular.z]);
        self.vel_publisher.publish(vel)
        dists = numpy.sqrt(self.minimum_dist_obstacle[0,:]**2 + self.minimum_dist_obstacle[1,:]**2)
        min_dist_obst = float(numpy.min(dists))


        plot_things_msg = Float32MultiArray()
        plot_things_msg.data = [r, min_dist_obst, vel.linear.x, vel.angular.z]
        self.plot_things_pub.publish(plot_things_msg)

def main():
    rclpy.init()
    dwa_node = Follow_Target()
    rclpy.spin(dwa_node)
    rclpy.shutdown()

if __name__=='__main__':
    main()

