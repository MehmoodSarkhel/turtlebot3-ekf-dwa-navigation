import rclpy
from geometry_msgs.msg import Twist
import numpy
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from rclpy.node import Node 
from Lab05.utilis_Task2 import clean_lidar, find_nearest_obstacle,Cost_evaluation
import math
from tf_transformations import euler_from_quaternion
from std_msgs.msg import Int32MultiArray

class Follow_Target(Node):
    def __init__(self):
        super().__init__('dwa_node');
        self.vel_publisher=self.create_publisher(Twist,'/cmd_vel',10);
        self.scan_sub=self.create_subscription(LaserScan,'/scan',self.update_scan,10);
        self.landmark_sub=self.create_subscription(Odometry,'/dynamic_goal_pose',self.update_target,10);

        self.metrics_pub = self.create_publisher(Int32MultiArray, '/metrics', 10)
        self.gt=self.create_subscription(Odometry,'/ground_truth',self.update_gt,10);

        self.flag_goal_reached=False;
        self.dt=1/15;
        self.timer=self.create_timer(self.dt,self.control_loop);
        self.get_logger().info("Follow Target Node initialized successfully.");
        self.treshold_stop=0.2;
        self.goal=numpy.array([3.5,3.5])
        self.w_sample=40;
        self.v_sample=20;
        self.max_acc=numpy.array([1.5,10.0])
        self.flag_goal=False;
        self.flag_obstacle=False;
        self.num=20;
        self.cmd_old=numpy.array([0.0,0.0]);
        self.max_linear=0.22;
        self.max_angular=2.84;
        self.minimum_dist_obstacle = numpy.ones((2, self.num)) * 3.5
        self.goal_pose=numpy.array([0.0,0.0]);
        self.robot_pose=numpy.array([0.0,0.0]);
        self.theta=0.0;
        self.inizialization_robot=False;
        self.treshold_goal=0.3;
        self.cont_success=0;
        self.cont_collision=0;
        self.cont_timeout=0;
        self.treshold_time_out=150;
        self.cont_no_reaching=0;
        self.cont=0;
        self.cont_total=0;
    
    def update_gt(self,msg):
        self.robot_pose=numpy.array([msg.pose.pose.position.x, msg.pose.pose.position.y]);
        q=msg.pose.pose.orientation;
        (_,_,yaw)=euler_from_quaternion([q.x,q.y,q.z,q.w]);
        self.theta=yaw;
        self.inizialization_robot=True;
    def update_target(self,msg):
        self.flag_goal=True;
        self.goal_pose=numpy.array([msg.pose.pose.position.x,msg.pose.pose.position.y]);
    
    def update_scan(self,msg):
        vect_lidar=numpy.array(msg.ranges);
        # self.get_logger().info(f"LIDAR data received : {vect_lidar}");
        vect_lidar=clean_lidar(vect_lidar);

        if min(vect_lidar)<self.treshold_stop:
            self.flag_obstacle=True;
            self.get_logger().info("Too Near to the Obstacle ");
        else:
            self.flag_obstacle=False;
            self.minimum_dist_obstacle=find_nearest_obstacle(vect_lidar,self.num);
            # self.lidar=self.minimum_dist_obstacle;
            # self.get_logger().info(f"The minimum distance from the robot to the obstacles is: {self.lidar}");
    
        
    
    def control_loop(self):
        self.cont_total=self.cont_total+1;
        metrics = Int32MultiArray();
        self.cont=self.cont+1;
        vel=Twist();
        diff=self.goal_pose - self.robot_pose;
        r=math.sqrt(diff[0]**2+diff[1]**2);
        bearing=math.atan2(diff[1],diff[0]) - self.theta;
        self.goal=numpy.array([r*math.cos(bearing),r*math.sin(bearing)]);
        if self.flag_goal==False:
            self.get_logger().info("No Goal detected ");
            vel.linear.x=0.0;
            vel.angular.z=0.0;
        else:
            if math.sqrt(self.goal[0]**2+self.goal[1]**2)<self.treshold_goal:
                self.cont_success=self.cont_success+1;
                self.flag_goal_reached=False;
                self.cont_no_reaching=0;
            elif self.flag_obstacle:
                self.cont_collision=self.cont_collision+1;
                self.cont_no_reaching=self.cont_no_reaching+1;
                if self.cont_no_reaching>self.treshold_time_out:
                    self.cont_timeout=self.cont_timeout+1;
            
            elif self.flag_obstacle==False  and self.inizialization_robot==True:
                    optimal_cmd=Cost_evaluation(self.cmd_old,self.max_acc,self.dt,self.goal,self.minimum_dist_obstacle,self.v_sample,self.w_sample,self.max_linear,self.max_angular)
                    vel.linear.x=optimal_cmd[0];
                    vel.angular.z=optimal_cmd[1];
                    self.get_logger().info("Optimal velocity found  ")
                    self.flag_obstacle=False;
        metrics.data = [self.cont_success, self.cont_collision, self.cont_timeout,self.cont_total]
        self.metrics_pub.publish(metrics)
        if self.cont==50:
            dist=math.sqrt(self.goal[0]**2+self.goal[1]**2);
            self.get_logger().info(f"Distange to the actual Goal :{dist}")
            self.cont=0;
        self.cmd_old=numpy.array([vel.linear.x,vel.angular.z]);
        self.vel_publisher.publish(vel)


def main():
    rclpy.init()
    dwa_node = Follow_Target()
    rclpy.spin(dwa_node)
    rclpy.shutdown()

if __name__=='main':
    main()