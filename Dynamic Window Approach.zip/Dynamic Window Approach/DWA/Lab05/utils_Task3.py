import numpy
import math    


def Cost_evaluation(cmd_old,max_acc,dt,goal,obstacle,v_samples,w_samples,max_linear,max_angular):
    # Parameters of the Cost function
    alfa=0.8;
    beta=0.5; 
    gamma=0.1; 
    #Pameters for Task 2 
    delta = 1.3; 
    desired_dist = 0.2   
    dist_threshold = 0.25  

    #############################################
    x_goal=goal[0];
    y_goal=goal[1];
    v_old=cmd_old[0];
    w_old=cmd_old[1];
    max_acc_v=max_acc[0];
    max_acc_w=max_acc[1];
    delta_v = max_acc_v*dt;
    delta_w=max_acc_w*dt;
    v_max=min(max_linear,v_old+delta_v)
    v_min=max(0,v_old-delta_v)
    w_max=min(max_angular,w_old+delta_w)
    w_min=max(-max_angular,w_old-delta_w)
    v_values=numpy.linspace(v_min,v_max,v_samples)
    w_values=numpy.linspace(w_min,w_max,w_samples)
    min_cost=float("inf");
    M=numpy.zeros((len(v_values),len(w_values)));
    v_optimal=0.0;
    w_optimal=0.0;
    T=0.3; """predict time"""
    for j, v in enumerate(v_values):
        for k, w in enumerate(w_values):
        
            if abs(w)<1e-5:
                x_new=v*T;
                y_new=0;
            else:
            
                x_new=(v/w)*math.sin(w*T)
                y_new=(1-math.cos(w*T))*(v/w);
            heading_to_goal = math.atan2(y_goal, x_goal)  
            theta_traj = math.atan2(y_new, x_new)
            heading_score =abs(math.atan2(math.sin(heading_to_goal - theta_traj),math.cos(heading_to_goal - theta_traj)))
            new_heading = heading_score / math.pi

            new_dist_obstacle=numpy.sqrt((y_new*numpy.ones(20)-obstacle[1,:])**2+(x_new*numpy.ones(20)-obstacle[0,:])**2);
            dist_obstacle=min(new_dist_obstacle);

            predicted_dist = math.sqrt((x_goal - x_new)**2 + (y_goal - y_new)**2)

            if dist_obstacle<0.1:
                continue
            elif v<=math.sqrt(2*(dist_obstacle-0.1)*max_acc_v):
                if predicted_dist < dist_threshold:
                    vel_prime = v * (dist_threshold - predicted_dist) / dist_threshold
                else:
                    vel_prime = 0.0

                
                dist_target_cost = (predicted_dist - desired_dist)**2

                M[j,k]=(alfa*new_heading)+(beta*vel_prime)+(gamma/dist_obstacle)+(delta * dist_target_cost)
                if M[j,k]<min_cost:
                        min_cost=M[j,k];
                        v_optimal=v;
                        w_optimal=w;
    return numpy.array([v_optimal,w_optimal])
    

def normalize_angle(angle):
    return (angle + math.pi) % (2.0 * math.pi) - math.pi

def clean_lidar(vect):
    for i in range(len(vect)):
        if math.isnan(vect[i]): 
            vect[i]=3.5 
        elif math.isinf(vect[i]):
            vect[i]=3.5;
    return vect

def find_nearest_obstacle(vect,num):
    angular_sector=numpy.array_split(vect,num);
    i=0;
    obstacle=numpy.zeros((2,num))
    range_min=0.1199
    angle_increment=0.0175
    for vect in angular_sector:
        dist=numpy.min(vect)
        theta= range_min+(angle_increment*i)+(angle_increment/2);
        obstacle[0,i]=dist*math.cos(theta);
        obstacle[1,i]=dist*math.sin(theta);
        i=i+1;
    return obstacle