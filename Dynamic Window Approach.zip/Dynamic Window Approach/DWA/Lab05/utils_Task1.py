import numpy
import math    


def Cost_evaluation(cmd_old,max_acc,dt,goal,obstacle,v_samples,w_samples,max_linear,max_angular):
    #Parameters for Cost Fuction:
    alfa=0.8;
    beta=-0.5; 
    gamma=0.5;
    
    #############################################
    x_goal=goal[0];
    y_goal=goal[1];
    v_old=cmd_old[0];
    w_old=cmd_old[1];
    max_acc_v=max_acc[0];
    max_acc_w=max_acc[1];
    delta_v = max_acc_v*dt;
    delta_w=max_acc_w*dt;
    v_max=min(max_linear,v_old+delta_v)
    v_min=max(0,v_old-delta_v)
    w_max=min(max_angular,w_old+delta_w)
    w_min=max(-max_angular,w_old-delta_w)
    v_values=numpy.linspace(v_min,v_max,v_samples)
    w_values=numpy.linspace(w_min,w_max,w_samples)
    min_cost=float("inf");
    M=numpy.zeros((len(v_values),len(w_values)));
    v_optimal=0.0;
    w_optimal=0.0;
    T=0.3; """predict time"""
    for j, v in enumerate(v_values):
        for k, w in enumerate(w_values):
        
            if abs(w)<1e-5:
                x_new=v*T;
                y_new=0;
            else:
            
                x_new=(v/w)*math.sin(w*T)
                y_new=(1-math.cos(w*T))*(v/w);
            heading_to_goal = math.atan2(y_goal, x_goal)  
            theta_traj = math.atan2(y_new, x_new)
            heading_score =abs(math.atan2(math.sin(heading_to_goal - theta_traj),math.cos(heading_to_goal - theta_traj)))
            new_heading = heading_score / math.pi
            new_dist_obstacle=numpy.sqrt((y_new*numpy.ones(20)-obstacle[1,:])**2+(x_new*numpy.ones(20)-obstacle[0,:])**2);
            dist_obstacle=min(new_dist_obstacle);
            if dist_obstacle<0.2:
                continue
            elif v<=math.sqrt(2*(dist_obstacle-0.15)*max_acc_v):
                new_v=v_values[j]
                M[j,k]=(alfa*new_heading)+(beta*new_v)+(gamma/dist_obstacle)
                if M[j,k]<min_cost:
                        min_cost=M[j,k];
                        v_optimal=v;
                        w_optimal=w;
    return numpy.array([v_optimal,w_optimal])
    

def normalize_angle(angle):
    return (angle + math.pi) % (2.0 * math.pi) - math.pi

def clean_lidar(vect):
    for i in range(len(vect)):
        if math.isnan(vect[i]): 
            vect[i]=0.15
        elif math.isinf(vect[i]):
            vect[i]=3.5;
    return vect

def find_nearest_obstacle(vect,num):
    angular_sector=numpy.split(vect,num);
    i=0;
    obstacle=numpy.zeros((2,num))
    for vect in angular_sector:
        dist=numpy.min(vect)
        theta=((2*math.pi)/num)*i+(math.pi/num);
        obstacle[0,i]=dist*math.cos(theta);
        obstacle[1,i]=dist*math.sin(theta);
        i=i+1;
    return obstacle