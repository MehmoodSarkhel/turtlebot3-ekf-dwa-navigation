from setuptools import find_packages, setup

package_name = 'Lab05'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='riccardoferranti',
    maintainer_email='riccardoferranti@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'DWA = Lab05.DWA:main'
            'DWA_Task2 = Lab05.DWA_Task2:main',
            'DWA_Real_Robot = Lab05.DWA_Real_Robot:main',
        ],
    },
)
